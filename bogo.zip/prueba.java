package Sorts;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

public class prueba {

	@Test
	public void testcheck() {
		quicksort meme =  new quicksort();
		ArrayList<Integer> lista = new ArrayList<Integer>();
		ArrayList<Integer> explista = new ArrayList<Integer>();
		ArrayList<Integer> lista2 = new ArrayList<Integer>();
		ArrayList<Integer> lista3 = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,2,3,4,5,6,8,7,9,10));
		lista2.addAll(Arrays.asList(1,1,1,2,1,1,1,1,1,1,1));
		lista3.addAll(Arrays.asList(1,2,3,4,5,6,7,8,9,10));
        
		if (quicksort.check(lista)) {
			
		}else {
			fail("Not yet implemented");
		}
		
		if (quicksort.check(lista2)) {
			
		}else {
			fail("Not yet implemented");
		}
		if (quicksort.check(lista3)) {
			fail("Not yet implemented");
		}else {
			
		}
		
	}
	
	@Test
	public void testquicksort() {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,3,3,4,5,6,8,7,9,10));
        quicksort.quicksorta(lista);
        
		if (quicksort.check(lista)) {
			fail("Not yet implemented");
		}
	}
	@Test
	public void testmerge() {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,3,3,4,5,6,8,7,9,10));
        mergesort.mergesorta(lista);
        
		if (quicksort.check(lista)) {
			fail("Not yet implemented");
		}
	}
	@Test
	public void testbogo() {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,3,2,4,5));
        bogo.bogosort(lista);
        
		if (quicksort.check(lista)) {
			fail("Not yet implemented");
		}
	}
	@Test
	public void testgnome() {
		Comparable[] lista = {1,2,5,4,1,6,7};
		Comparable[] lista2 = {1,2,3,4,5,6,7};
        
		Sorts.GnomeSort(lista);
        
		if (lista==lista2) {
			fail("Not yet implemented");
		}
	}
	
	@Test
	public void testbubble() {
		Comparable[] lista = {1,2,5,4,1,6,7};
		Comparable[] lista2 = {1,2,3,4,5,6,7};
        
		Sorts.bubbleSort(lista);
        
		if (lista==lista2) {
			fail("Not yet implemented");
		}
	}
	
	@Test
	public void testradix() {
		Comparable[] lista = {1,2,5,4,1,6,7};
		Comparable[] lista2 = {1,2,3,4,5,6,7};
        
		//No se como crear la lista de radix
        
		if (lista==lista2) {
			fail("Not yet implemented");
		}
	}
}
