package Sorts;

import java.util.Random;
import java.util.ArrayList;
import java.util.List;


public class quicksort implements Comparable<quicksort>{

	public static ArrayList<Integer> quicksorta(ArrayList<Integer> lista) {
		//Se utiliza ArrayList envez de Linkedlist porque se requiere acceder a elementos aleatorios frecuentemente
		
		boolean verif = true;
		
		while (verif){
			
			Random generator = new Random();
			int pivotpos = generator.nextInt(lista.size());
			
			int pivot = lista.get(pivotpos);
			
			lista.remove(pivotpos);
			
			ArrayList<Integer> menor = new ArrayList<Integer>();
			ArrayList<Integer> mayor = new ArrayList<Integer>();
			
			for (int i = 0; i<lista.size(); i++) {
				if (lista.get(i)<pivot) {
					menor.add(lista.get(i));
				}else {
					mayor.add(lista.get(i));
				}
			}
	     
	        //System.out.println("Lista " + lista);

	        //System.out.println("Pivot " + pivot);

	        //System.out.println("Menor " + menor);

	        //System.out.println("Mayor " + mayor);
			
			
			
			lista.clear();
			
			lista.addAll(menor);
			lista.add(pivot);
			lista.addAll(mayor);
			
			//System.out.println("Nueva Lista");
			//System.out.println(lista);
			
			verif = check(lista);
		}
	
		
		List<Integer>  ordenada = lista.subList(0, lista.size());
		return lista;
	}
	
	public static boolean check(ArrayList<Integer> secuencia) {
		
		
		for (int i = 0; i+1<secuencia.size(); i++) {
			if (secuencia.get(i)>secuencia.get(i+1)) {
				return true;	
			}
			//System.out.println(secuencia.get(i)+" Es menor que "+secuencia.get(i+1));
		}	
		
		return false;
	}

	@Override
	public int compareTo(quicksort o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
