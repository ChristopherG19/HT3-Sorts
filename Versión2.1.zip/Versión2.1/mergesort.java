import java.util.ArrayList;
import java.util.List;

public class mergesort {

	public static ArrayList<Integer> mergesorta(ArrayList<Integer> lista) {

		boolean verif = true;
		
		while (verif){
			//System.out.println("Lista" +lista);
			
			List<Integer>  temp1a = lista.subList(0, lista.size()/2);
			List<Integer>  temp2a = lista.subList(lista.size()/2,lista.size());
			ArrayList<Integer> temp1 = new ArrayList<Integer>();
			ArrayList<Integer> temp2 = new ArrayList<Integer>();
			ArrayList<Integer> temp3 = new ArrayList<Integer>();
			
			temp1.addAll(temp1a);
			temp2.addAll(temp2a);
			
			//System.out.println(temp1);
			//System.out.println(temp2);
			
			if (quicksort.check(temp1) == false && quicksort.check(temp2) == false){
				//System.out.println("Estan ordenadas");
				while (temp1.isEmpty() != true && temp2.isEmpty() != true) {
					int x = temp1.get(0);
					int y = temp2.get(0);
					
					//System.out.println(x+">"+y);
					if (x<y) {
						temp3.add(x);
						temp1.remove(0);
					}else {
						temp3.add(y);
						temp2.remove(0);
					}
				}
				if (temp1.isEmpty() == false){
					temp3.addAll(temp1);
				} else if (temp2.isEmpty() == false) {
					temp3.addAll(temp2);
				}
				
				lista.clear();
				lista.addAll(temp3);
				//System.out.println(lista);
				return lista;
			} else if(quicksort.check(temp1) == true && quicksort.check(temp2) == false){
				temp1 =mergesorta(temp1);
			} else if(quicksort.check(temp2) == true && quicksort.check(temp1) == false){
				temp2 = mergesorta(temp2);
			} else if(quicksort.check(temp1) == true && quicksort.check(temp2) == true){
				temp1 = mergesorta(temp1);
				temp2 = mergesorta(temp2);
				
			}
			lista.clear();
			lista.addAll(temp1);
			lista.addAll(temp2);
			//System.out.println(lista+" "+temp1+" "+temp2+" "+temp3);
			
			lista = mergesorta(lista);
		}
		
		return lista;
		
	}

}
