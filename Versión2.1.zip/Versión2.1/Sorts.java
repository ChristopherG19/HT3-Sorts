import java.util.Arrays;

public class Sorts {
    
    public static void GnomeSort(Comparable[] lista){

        Comparable Compa;
        int a = 1;
        int b = 2;

        while(a<lista.length){
            if(lista[a-1].compareTo(lista[a]) < 0){
                Compa = lista[a-1];
                lista[a-1] = lista[a];
                lista[a--] = Compa;
                a = (a==0) ? b++ : a;
            } else {
                a = b;
                b++;
            }
        }
    }

    static int DatoMayor(Numeros[] evaluar, int Extra){
        
        int Mayor = evaluar[0].getFinalNumber();
        for(int i = 1; i < Extra; i++){
            if(evaluar[i].getFinalNumber() > Mayor){
                Mayor = evaluar[i].getFinalNumber();
            }
        }

        return Mayor;
    }

    static void SortCuenta(Numeros[] NumC, int Lugar, int Por){

        int Inicio;
        int cuenta[] = new int[10];
        Numeros SalidaFinal[] = new Numeros[Lugar];
        Arrays.fill(cuenta, 0);

        for(Inicio = 0; Inicio < Lugar; Inicio++){
            cuenta[(NumC[Inicio].getFinalNumber() / Por) % 10]++;
        }
        
        for(Inicio = 1; Inicio < 10; Inicio++){
            cuenta[Inicio] += cuenta[Inicio-1]; 
        }

        for(Inicio = Lugar-1; Inicio >= 0; Inicio--){
            SalidaFinal[cuenta[(NumC[Inicio].getFinalNumber() / Por) % 10] - 1] = NumC[Inicio];
            cuenta[(NumC[Inicio].getFinalNumber() / Por) % 10]--;
        }

        for(Inicio = 0; Inicio < Lugar; Inicio++){
            NumC[Inicio] = SalidaFinal[Inicio];
        }

    }

    static String RadixSort(Numeros[] Num, int es){

        int Temp = DatoMayor(Num, es);
    
        for(int am = 1; Temp / am > 0; am *= 10){
            SortCuenta(Num, es, am);
        }

        String f = "Han sido ordenados tus datos, son los siguientes: ";
        return f;
    
    }

    public static void bubbleSort(Comparable[] ListaEvaluar){
        int SS = ListaEvaluar.length; 
        for (int h = 0; h < SS-1; h++) {
            for (int i = 0; i < SS-h-1; i++){
              if (ListaEvaluar[i].compareTo(ListaEvaluar[i+1]) < 0 )  
                { 
                    Comparable Comparar = ListaEvaluar[i]; 
                    ListaEvaluar[i] = ListaEvaluar[i+1]; 
                    ListaEvaluar[i+1] = Comparar; 
                }  
            } 
        }  
    }

    
}
