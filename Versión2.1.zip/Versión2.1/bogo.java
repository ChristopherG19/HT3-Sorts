import java.util.ArrayList;
import java.util.Collections;

public class bogo {

	public static void bogosort(ArrayList<Integer> lista) {
		
		int intentos = 0;
		boolean verif = quicksort.check(lista);
		
		while (verif) {
			Collections.shuffle(lista);
			System.out.println(lista + " " + intentos);
			verif = quicksort.check(lista);
			intentos +=1;
		}
		
		System.out.println("La lista fue ordenada en "+intentos+" intentos");
		
	}
}
