import java.util.Scanner;

public class Pruebas {
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int NumeroOpcion;
        boolean x = false;

        try {
            
            while(x != true){
                System.out.println("\n-------Sort Program------\n");
                System.out.println("Opciones a elegir: ");
                System.out.println("1) Gnome Sort");
                System.out.println("2) Merge Sort");
                System.out.println("3) Quick Sort");
                System.out.println("4) Radix Sort");
                System.out.println("5) Bubble Sort");
                System.out.println("6) Salir del programa\n");
                System.out.print("Que opcion desea probar?: ");
                String Opcionf = scan.nextLine();
                NumeroOpcion = Integer.parseInt(Opcionf);

                if(NumeroOpcion <= 0){
                    System.out.println("Lo siento, no es una opcion");
                } else if(NumeroOpcion == 1){


                } else if(NumeroOpcion == 2){

                    System.out.println("\norden");


                } else if(NumeroOpcion == 3){
                    
                } else if(NumeroOpcion == 4){
                        
                } else if(NumeroOpcion == 5){
                        
                } else if(NumeroOpcion == 6){
                    System.out.println("\nQue tenga un feliz día");
                    x = true;
                } else {
                    System.out.println("Lo siento, no es una opcion");
                }
            }

        } catch (Exception e) {
            System.out.println("No es un numero");
        }
        scan.close();




    }

}
