package Sorts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class Main {
    
    public static void main(String args[]){

        ArrayList<Integer> Num = new ArrayList<Integer>();
        Scanner scan = new Scanner(System.in);
        boolean x = false;
        int b = 0;

        GeneradorAleatorios(Num);
        Numeros[] Lista = new Numeros[3000];
        for(int i = 0; i < 3000; i++){
            Lista[i] = new Numeros(Num.get(i));
        } 
            
        try {
            int NumeroOpcion;

            while(!x){
                System.out.println("\n-------Sort Program------\n");
                System.out.println("Opciones a elegir: ");
                System.out.println("1) Gnome Sort");
                System.out.println("2) Merge Sort");
                System.out.println("3) Quick Sort");
                System.out.println("4) Radix Sort");
                System.out.println("5) Bubble Sort");
                System.out.println("6) Bogo Sort");
                System.out.println("7) Salir del programa\n");
                System.out.print("Que opcion desea probar?: ");
                String Opcionf = scan.nextLine();
                NumeroOpcion = Integer.parseInt(Opcionf);

                if(NumeroOpcion <= 0){
                    System.out.println("Lo siento, no es una opcion");
                } else if(NumeroOpcion == 1){

                    Sorts.GnomeSort(Lista);
                    for(Numeros Final : Lista){
                        System.out.println(Final);
                        b++;
                    }
                    Generador(Lista);
                        
                    System.out.println("Total de datos: "+ b);
                    System.out.println("Archivo con datos ordenados creado exitosamente\n");
                    b = 0;

                } else if(NumeroOpcion == 2){
                    
                    GeneradorAleatorios(Num);
                    mergesort.mergesorta(Num);

                } else if(NumeroOpcion == 3){
                	
                	GeneradorAleatorios(Num);
                	System.out.println(Num);
                    quicksort.quicksorta(Num);
                    System.out.println(Num);
                    Generador2(Num);

                } else if(NumeroOpcion == 4){
            
                    String orden = Sorts.RadixSort(Lista, Lista.length);
                    System.out.println(orden);
                    
                    for(Numeros DatosFinales : Lista){
                        System.out.println(DatosFinales);
                        b++;
                    }
                    Generador(Lista);

                    System.out.println("Total de datos: "+ b);
                    System.out.println("Archivo con datos ordenados creado exitosamente\n");
                    b = 0;

                } else if(NumeroOpcion == 5){

                    Sorts.bubbleSort(Lista);

                    for(Numeros NumF : Lista){
                        System.out.println(NumF);
                        b++;
                    }
                    Generador(Lista);

                    System.out.println("Total de datos: " + b);
                    System.out.println("Archivo con datos ordenados creado exitosamente\n");
                    b=0; 

                } else if(NumeroOpcion == 6){
                	
                	ArrayList<Integer> Stringbogo = new ArrayList<Integer>();
                    Stringbogo.addAll(Arrays.asList(2,1,3,4,5,6,7,8,9,10));
                    bogo.bogosort(Stringbogo);

                } else if(NumeroOpcion == 7){
                    System.out.println("\nQue tenga un feliz día");
                    x = true;
                } else {
                    System.out.println("Lo siento, no es una opcion");
                }
            }

        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No es un numero");
        }
        scan.close();
    }

    public static void GeneradorAleatorios(ArrayList<Integer> Num){

        Num.clear();
        Random ran = new Random();

        for(int i = 0; i < 3000; i++){
            Num.add(ran.nextInt(3000));
        }

        try {
            String ruta = "NumerosDesordenados.txt";
            File file = new File(ruta);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            for(int a = 0; a < Num.size(); a++){
                bw.write(Num.get(a) + "\n");
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void Generador(Numeros[] Num){

        try {
            String ruta = "NumerosOrdenados.txt";
            File file = new File(ruta);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            for(int a = 0; a < Num.length; a++) {
                bw.write(Num[a]+ "\n");
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    public static void Generador2(ArrayList<Integer>  Num){

        try {
            String ruta = "NumerosOrdenados.txt";
            File file = new File(ruta);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            for(int a = 0; a < Num.size(); a++) {
                bw.write(Num.get(a)+ "\n");
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
