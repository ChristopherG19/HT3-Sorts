package Sorts;

public class Numeros implements Comparable<Numeros> {

    private Integer NumeroFinal;

    public Numeros(Integer Final){
        NumeroFinal = Final;
    }

    public Integer getFinalNumber(){
        return NumeroFinal;
    }

    @Override
    public int compareTo(Numeros Numero) {
        Integer DatoExtra = ((Numeros)Numero).getFinalNumber();
        Integer ResultadoFinal;

        ResultadoFinal = DatoExtra.compareTo(NumeroFinal);
        
        return ResultadoFinal;
    }

    public String toString(){
        return String.valueOf(NumeroFinal);
    }
    

    
}
