/**
 * Universidad del Valle de Guatemala
 * Algoritmos y Estructura de Datos - Sección 10
 * @version 3.1
 * @author Christopher García 20541
 * @author José Monzón
 */

/**
 * Imports
 */
import java.util.ArrayList;
import java.util.Collections;

/**
 * Inicio de clase BogoSort
 */
public class BogoSort {

    /**
     * Método bogoSort
     * @param ListaNum: Lista desordenada de 3000 números aleatorios
     */
    public static void bogoSort(ArrayList<Integer> ListaNum){

        /**
         * Instancias para determinar cuando terminar el ciclo while
         * y cuantas veces se repite para determinar cuanto intentos
         * le tomó para ordenar la lista
         */
        int intentos = 0;
        boolean verific = QuickSort.check(ListaNum);

        /**
         * Este método Sort no es muy efectivo. Se ordena de manera aleatoria
         * hasta que los datos quedén correctamente ordenados
         */
        while(verific) {
            Collections.shuffle(ListaNum);
            System.out.println(ListaNum + " " + intentos);
            verific = QuickSort.check(ListaNum);
            intentos +=1;
        }

        /**
         * Se imprimen los intentos que le tomó al método ordenar la lista
         */
        System.out.println("La lista fue ordenada en: " + intentos + " intentos");

    }
}
