import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;

public class JUnit {

	@Test
	public void testcheck() {
		QuickSort meme =  new QuickSort();
		ArrayList<Integer> lista = new ArrayList<Integer>();
		ArrayList<Integer> explista = new ArrayList<Integer>();
		ArrayList<Integer> lista2 = new ArrayList<Integer>();
		ArrayList<Integer> lista3 = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,2,3,4,5,6,8,7,9,10));
		lista2.addAll(Arrays.asList(1,1,1,2,1,1,1,1,1,1,1));
		lista3.addAll(Arrays.asList(1,2,3,4,5,6,7,8,9,10));
        
		if (QuickSort.check(lista)) {
			
		}else {
			fail("Not yet implemented");
		}
		
		if (QuickSort.check(lista2)) {
			
		}else {
			fail("Not yet implemented");
		}
		if (QuickSort.check(lista3)) {
			fail("Not yet implemented");
		}else {
			
		}
		
	}
	
	@Test
	public void testquicksort() {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,3,3,4,5,6,8,7,9,10));
		QuickSort.quickSort(lista);
        
		if (QuickSort.check(lista)) {
			fail("Not yet implemented");
		}
	}
	@Test
	public void testmerge() {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,3,3,4,5,6,8,7,9,10));
        MergeSort.mergeSort(lista);
        
		if (QuickSort.check(lista)) {
			fail("Not yet implemented");
		}
	}
	@Test
	public void testbogo() {
		ArrayList<Integer> lista = new ArrayList<Integer>();
		
		lista.addAll(Arrays.asList(1,3,2,4,5));
        BogoSort.bogoSort(lista);
        
		if (QuickSort.check(lista)) {
			fail("Not yet implemented");
		}
	}
	@Test
	public void testgnome() {
        Numeros[] lista = new Numeros[10];
        ArrayList<Integer> Nume = new ArrayList<Integer>();
        for(int o = 0; o < 10; o++){
            lista[o] = new Numeros(Nume.get(o));
        }
        
		Comparable[] lista2 = {1,2,3,4,5,6,7};
        
		SortsHT.GnomeSort(lista);
        
		if (lista==lista2) {
			fail("Not yet implemented");
		}
	}
	
	@Test
	public void testbubble() {
		Comparable[] lista = {1,2,5,4,1,6,7};
		Comparable[] lista2 = {1,2,3,4,5,6,7};
        
		SortsHT.BubbleSort(lista);
        
		if (lista==lista2) {
			fail("Not yet implemented");
		}
	}
	
	@Test
	public void testradix() {
		Comparable[] lista = {1,2,5,4,1,6,7};
		Comparable[] lista2 = {1,2,3,4,5,6,7};
        
		//No se como crear la lista de radix
        
		if (lista==lista2) {
			fail("Not yet implemented");
		}
	}
}
