/**
 * Universidad del Valle de Guatemala
 * Algoritmos y Estructura de Datos - Sección 10
 * @version 3.1
 * @author Christopher García 20541
 * @author José Monzón
 */

/**
 * Imports
 */
import java.util.ArrayList;
import java.util.Random;

/**
 * Inicio de clase QuickSort que implementa Comparable
 */
public class QuickSort implements Comparable<QuickSort> {

    /**
     * Método quickSort: Compara dos números tomando uno de estos como pivote
     * y verificando con cada uno hasta ordenar la lista
     * @param ListN: Lista de números aleatorios desordenada
     * @return: Lista de números ordenada correctamente
     */
    public static ArrayList<Integer> quickSort(ArrayList<Integer> ListN){
        
        boolean Verifi = true;

        while(Verifi){

            Random generador = new Random();
            int PivotePos = generador.nextInt(ListN.size());
            int Pivote = ListN.get(PivotePos);

            ListN.remove(PivotePos);

            ArrayList<Integer> Menor = new ArrayList<Integer>();
            ArrayList<Integer> Mayor = new ArrayList<Integer>();

            for(int i = 0; i < ListN.size(); i++){
                if (ListN.get(i) < Pivote){
                    Menor.add(ListN.get(i));
                } else {
                    Mayor.add(ListN.get(i));
                }
            }

            ListN.clear();
            ListN.addAll(Menor);
            ListN.add(Pivote);
            ListN.addAll(Mayor);

            Verifi = check(ListN);

        }

        return ListN;

    }

    /**
     * Método para revisar que la lista está ordenada correctamente
     * @param Secuencia: Lista "ordendada"
     * @return: true si la lista ha sido correctamente ordenada, false si no está ordenada
     */
    public static boolean check(ArrayList<Integer> Secuencia){

        for(int f = 0; f+1 < Secuencia.size(); f++){
            if(Secuencia.get(f) > Secuencia.get(f+1)){
                return true;
            }
        }

        return false;
    }

    @Override
    public int compareTo(QuickSort o) {
        return 0;
    }
}
