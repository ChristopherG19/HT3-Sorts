/**
 * Universidad del Valle de Guatemala
 * Algoritmos y Estructura de Datos - Sección 10
 * @version 3.1
 * @author Christopher García 20541
 * @author José Monzón
 */

/**
 * Imports
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 * Inicio de clase Main
 */
public class Main {
    public static void main(String[] args) {

        /**
         * Instancias necesarias para la ejecución del programa
         */
        ArrayList<Integer> Nume = new ArrayList<Integer>();
        Scanner scan = new Scanner(System.in);
        boolean Ver = false;
        int X1 = 0;

        /**
         * Se llama a este metodo para poder generar los números del 0-3000 de manera aleatoria
         * y crear un archivo txt donde se almacenan
         *
         * También se crea la lista con la que se trabajara y será ordenada por los métodos sort
         */
        GeneradorNumAleatorios(Nume);
        Numeros[] Lis = new Numeros[3000];
        for(int o = 0; o < 3000; o++){
            Lis[o] = new Numeros(Nume.get(o));
        }

        /**
         * Try-catch para evitar que el usuario ingrese algún dato erróneo
         */
        try {
            
            int OpcionU;

            /**
             * Inicio del menú
             */
            while(!Ver){

                System.out.println("\n-------Sort Program------\n");
                System.out.println("Opciones a elegir: ");
                System.out.println("1) Gnome Sort");
                System.out.println("2) Merge Sort");
                System.out.println("3) Quick Sort");
                System.out.println("4) Radix Sort");
                System.out.println("5) Bubble Sort");
                System.out.println("6) Bogo Sort");
                System.out.println("7) Salir del programa\n");
                System.out.print("Que opcion desea probar?: ");

                /**
                 * Se lee el input del usuario y se convierte a un integer para
                 * trabajar de manera más efectiva
                 */
                String OpcionFU = scan.nextLine();
                OpcionU = Integer.parseInt(OpcionFU);

                /**
                 * Si el usuario ingresa algún dato menor a 0
                 * muestra una advertencia
                 */
                if (OpcionU <= 0){
                
                    System.out.println("Lo siento, no es una opcion");

                /**
                * Opcion 1, se ordena la lista con GnomeSort
                */
                } else if (OpcionU == 1){

                    /**
                     * @param Lis: Lista que contiene 3000 números al azar
                     * Se llama al método GnomeSort
                     */
                    SortsHT.GnomeSort(Lis);

                    /**
                     * Se imprimen los valores de la lista ya ordenada
                     */
                    for(Numeros Res : Lis){
                        System.out.println(Res);
                        X1++;
                    }

                    /**
                     * Se crea un txt con los datos ya ordenados
                     * y se muestra la cantidad de datos ordenados
                     */
                    Generadortxt(Lis);
                    System.out.println("Total de datos ordenados: " + X1);
                    System.out.println("Archivo .txt con datos ordenados creado exitosamente\n");
                    X1 = 0;

                /**
                *Opcion 2: Ordena la lista con MergeSort
                */
                } else if (OpcionU == 2){

                    /**
                     * Se crea el archivo txt con los 3000 numeros aleatorios
                     * y se muestra la lista desordenada
                     */
                    GeneradorNumAleatorios(Nume);
                    System.out.println("\nLista de numeros desordenados: \n");
                    System.out.println(Nume);
                    /**
                     * @param Nume: Lista desordenada con 3000 numeros aleatorios
                     * Se llama el método mergeSort
                     */
                    MergeSort.mergeSort(Nume);
                    /**
                     * Se imprime la lista ya ordenada y se crea el archivo txt
                     * Este archivo contiene la lista ya ordenada
                     */
                    System.out.println("\nLista de numeros ordenados: \n");
                    System.out.println(Nume);
                    Generadortxt2(Nume);
                    System.out.println("Archivo .txt con datos ordenados creado exitosamente\n");

                /**
                * Opcion 3: Ordena la lista con QuickSort
                */
                } else if (OpcionU == 3){

                    /**
                     * Se repite el proceso de la anterior opcion
                     * solo que en este caso se llama al método quickSort
                     */
                    GeneradorNumAleatorios(Nume);
                    System.out.println("\nLista de numeros desordenados: \n");
                    System.out.println(Nume);
                    QuickSort.quickSort(Nume);
                    System.out.println("\nLista de numeros ordenados: \n");
                    System.out.println(Nume);
                    Generadortxt2(Nume);
                    System.out.println("Archivo .txt con datos ordenados creado exitosamente\n");

                /**
                * Opcion 4: Se ordena la lista con RadixSort
                */
                } else if (OpcionU == 4){

                    /**
                     * Se imprime un String como comprobación de que
                     * el método se ha ejecutado correctamente, durante este
                     * proceso se ordena la lista
                     *
                     * @param Lis: Lista de 3000 numeros aleatorios desordenada
                     * @param Lis.length: Tamaño de la lista
                     */
                    String Ord = SortsHT.RadixSort(Lis, Lis.length);
                    System.out.println(Ord);

                    /**
                     * Se imprimen los datos ordenados para comprobar
                     * que se ordenaron correctamente
                     */
                    for(Numeros DataFin : Lis){
                        System.out.println(DataFin);
                        X1++;
                    }
                    /**
                     * Se crea el archivo txt con los datos ya ordenados
                     */
                    Generadortxt(Lis);
                    System.out.println("Total de datos ordenados: " + X1);
                    System.out.println("Archivo .txt con datos ordenados creado exitosamente\n");
                    X1 = 0;

                /**
                * Opcion 5: Se ordena la lista con BubbleSort
                */
                } else if (OpcionU == 5){

                    /**
                     * Se llama al método BubbleSort y se ordena la lista
                     * Posteriormente se imprimen los valores ordenados y
                     * se crea un archivo txt con estos datos
                     */
                    SortsHT.BubbleSort(Lis);
                    for(Numeros NumeFF : Lis){
                        System.out.println(NumeFF);
                        X1++;
                    }
                    Generadortxt(Lis);

                    System.out.println("Total de datos ordenados: " + X1);
                    System.out.println("Archivo .txt con datos ordenados creado exitosamente\n");
                    X1 = 0;

                /**
                * Opcion 6: Se ordena la lista con BogoSort
                * Este sort es extra, no fue solicitado ni requerido
                */
                } else if (OpcionU == 6){

                    /**
                     * Debido a que este Sort es mucho menos efectivo
                     * que los anteriores y tarda más se restringieron los
                     * datos de 1 a 7
                     *
                     * Se llama al metodo BogoSort y se ordena la lista de 7 datos
                     * Posterior a ser ordenado se crea un archivo txt con estos datos
                     */
                    ArrayList<Integer> StringBogo = new ArrayList<Integer>();
                    StringBogo.addAll(Arrays.asList(2,1,3,4,5,6,7));
                    BogoSort.bogoSort(StringBogo);
                    Generadortxt2(StringBogo);
                    System.out.println("Archivo .txt con datos ordenados creado exitosamente\n");

                /**
                * Opcion 7: El usuario desea salir del programa
                */
                } else if (OpcionU == 7){
                    System.out.println("\nQue tenga un feliz día\n\n");
                    Ver = true;

                /**
                * Cualquier otro dato ingresado no es aceptado
                */
                } else {
                    System.out.println("Lo siento, no es una opcion");
                }
            }
        /**
        * Se captura cualquier excepcion por datos ingresados erróneos
        */
        } catch (Exception e) {
            System.out.println(e);
            System.out.println("No es un dato numerico, intente de nuevo");
        }
        scan.close();
    }

    /**
     * Método para crear la lista de números aleatorios
     * @param Numer: ArrayList donde se crea la lista de 3000 datos
     */
    public static void GeneradorNumAleatorios(ArrayList<Integer> Numer){

        /**
         * Se borra cualquier dato que pueda tener (Como precaución)
         * Se crea una instancia de Random para generar los 3000 datos
         */
        Numer.clear();
        Random rando = new Random();

        /**
         * Se crean los 3000 datos y se guarda en el Arraylist
         */
        for(int q = 0; q < 3000; q++){
            Numer.add(rando.nextInt(3000));
        }

        /**
         * Try-catch para la creación del archivo txt que contendrá los
         * datos desordenados y evitar que no se guarde o cree correctamente
         */
        try {
            String Nombre = "NumerosDesordenados.txt";
            File file = new File(Nombre);
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter FW = new FileWriter(file);
            BufferedWriter BW = new BufferedWriter(FW);
            for (int r = 0; r < Numer.size(); r++){
                BW.write(Numer.get(r) + "\n");
            }
            BW.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Método que permite la creación de un archivo txt con los datos ordenados
     * @param Nums: Lista de números ya ordenados
     */
    public static void Generadortxt(Numeros[] Nums){

        try {
            String Nombre = "NumerosOrdenados.txt";
            File file = new File(Nombre);
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter FW = new FileWriter(file);
            BufferedWriter BW = new BufferedWriter(FW);
            for (int s = 0; s < Nums.length; s++){
                BW.write(Nums[s] + "\n");
            }
            BW.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * Método que cumple la función del anterior solo que este recibe
     * como parámetro un Arraylist ordenado
     * @param Nums: Arraylist de numeros ordenados
     */
    public static void Generadortxt2(ArrayList<Integer> Nums){

        try {
            String Nombre = "NumerosOrdenados.txt";
            File file = new File(Nombre);
            if(!file.exists()){
                file.createNewFile();
            }
            FileWriter FW = new FileWriter(file);
            BufferedWriter BW = new BufferedWriter(FW);
            for (int t = 0; t < Nums.size(); t++){
                BW.write(Nums.get(t) + "\n");
            }
            BW.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}