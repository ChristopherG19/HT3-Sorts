/**
 * Universidad del Valle de Guatemala
 * Algoritmos y Estructura de Datos - Sección 10
 * @version 3.1
 * @author Christopher García 20541
 * @author José Monzón
 */

/**
 * Inicio de clase Numeros que implementa Comparable de Java con genéricos
 */
public class Numeros implements Comparable<Numeros> {

    /**
     * Instancias
     */
    private Integer NumeroFi;

    /**
     * Constructor de la clase
     * @param Fin: El número ingresado será el número final a evaluar
     */
    public Numeros(Integer Fin){
        NumeroFi = Fin;
    }

    /**
     * Getter
     * @return: Retorna el numero final privado
     */
    public Integer getFinalNum(){
        return NumeroFi;
    }

    /**
     * Override de la clase que implementa
     * @param NumX: Lista de números a comparar
     * @return: Retorna el número final de la lista por medio de un comparación
     */
    @Override
    public int compareTo(Numeros NumX) {
       
        Integer Extra = ((Numeros)NumX).getFinalNum();
        Integer ResultFin;

        ResultFin = Extra.compareTo(NumeroFi);

        return ResultFin;
    }

    /**
     * ToString
     * @return: El valor del número final en forma de String
     */
    public String toString(){
        return String.valueOf(NumeroFi);
    }
    
}
