/**
 * Universidad del Valle de Guatemala
 * Algoritmos y Estructura de Datos - Sección 10
 * @version 3.1
 * @author Christopher García 20541
 * @author José Monzón
 */

/**
 * Imports
 */
import java.util.ArrayList;
import java.util.List;

/**
 * Inicio de clase MergeSort que implementa Comparable de Java
 */
public class MergeSort implements Comparable<MergeSort> {

    /**
     * Método mergeSort: Separa la lista en pequeñas porciones y verifica entre estas
     * que dato es el más pequeño
     * @param ListaN: Lista desordenada de 3000 numeros aleatorios
     * @return: Retorna la lista ordenada por completo
     */
    public static ArrayList<Integer> mergeSort(ArrayList<Integer> ListaN){

        boolean Verificador = true;

        while(Verificador){

            List<Integer> temp1a = ListaN.subList(0, ListaN.size() / 2);
            List<Integer> temp2a = ListaN.subList(ListaN.size()/2, ListaN.size());
            ArrayList<Integer> temp1 = new ArrayList<Integer>();
            ArrayList<Integer> temp2 = new ArrayList<Integer>();
            ArrayList<Integer> temp3 = new ArrayList<Integer>();

            temp1.addAll(temp1a);
            temp2.addAll(temp2a);

            if (QuickSort.check(temp1) == false && QuickSort.check(temp2) == false){

                while(temp1.isEmpty() != true && temp2.isEmpty() != true){
                    int x = temp1.get(0);
                    int y = temp2.get(0);

                    if (x < y){
                        temp3.add(x);
                        temp1.remove(0);
                    } else {
                        temp3.add(y);
                        temp2.remove(0);
                    }
                }

                if (temp1.isEmpty() == false){
                    temp3.addAll(temp1);
                } else if (temp2.isEmpty() == false){
                    temp3.addAll(temp2);
                }

                ListaN.clear();
                ListaN.addAll(temp3);

                return ListaN;

            } else if (QuickSort.check(temp1) == true && QuickSort.check(temp2) == false){
                temp1 = mergeSort(temp1);

            } else if (QuickSort.check(temp2) == true && QuickSort.check(temp1) == false){
                temp2 = mergeSort(temp2);

            } else if (QuickSort.check(temp1) == true && QuickSort.check(temp2) == true){
                temp1 = mergeSort(temp1);
                temp2 = mergeSort(temp2);
            }

            ListaN.clear();
            ListaN.addAll(temp1);
            ListaN.addAll(temp2);

            ListaN = mergeSort(ListaN);
        }

        return ListaN;
    }


    @Override
    public int compareTo(MergeSort o) {
        return 0;
    }
}
