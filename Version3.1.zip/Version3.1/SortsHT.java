/**
 * Universidad del Valle de Guatemala
 * Algoritmos y Estructura de Datos - Sección 10
 * @version 3.1
 * @author Christopher García 20541
 * @author José Monzón
 */

/**
 * Imports
 */
import java.util.Arrays;

/**
 * Inicio de clase SortsHT: Contiene 3 sorts distintos
 */
public class SortsHT {

    /**
     * Inicio de método GnomeSort: Revisa parejas de números, si en dado caso realiza
     * un cambio regresa a la anterior pareja y evalua con el nuevo dato hasta
     * ordenar la lista
     * @param ListA: Lista de números aleatorios desordenada
     */
    public static void GnomeSort(Comparable<Numeros>[] ListA){

        Comparable<Numeros> Comparar;
        int Num1 = 1;
        int Num2 = 2;

        while (Num1 < ListA.length){

            if (ListA[Num1-1].compareTo((Numeros) ListA[Num1]) < 0){
                
                Comparar = ListA[Num1-1];
                ListA[Num1-1] = ListA[Num1];
                ListA[Num1--] = Comparar;
                Num1 = (Num1==0) ? Num2++ : Num1;
            
            } else {

                Num1 = Num2;
                Num2++;

            }
        }
    }

    /**
     * Método para encontrar el número más grande de la lista
     * @param Evaluar: Lista de números aleatorios desordenada
     * @param Ext: Numero más grande posible en la lista
     * @return
     */
    public static int NumMayor(Numeros[] Evaluar, int Ext){

        int NumMa = Evaluar[0].getFinalNum();
        for(int h = 0; h < Ext; h++){
            if(Evaluar[h].getFinalNum() > NumMa){
                NumMa = Evaluar[h].getFinalNum();
            }
        }

        return NumMa;
    }

    /**
     * Método sortC: Parte fundamental para que funcione el método RadixSort
     * Evalua cada unidad del número(unidad, decena, centena, milésima)
     * @param NumSC: Lista de números desordenada
     * @param Lul: tamaño de la lista
     * @param XPor: Número para realizar las divisiones de las unidades
     */
    public static void SortC(Numeros[] NumSC, int Lul, int XPor){

        int Start;
        int Cuenta[] = new int[10];
        Numeros OutFinal[] = new Numeros[Lul];
        Arrays.fill(Cuenta, 0);

        for (Start = 0; Start < Lul; Start++){
            Cuenta[(NumSC[Start].getFinalNum() / XPor) % 10]++;
        }

        for (Start = 1; Start < 10; Start++){
            Cuenta[Start] += Cuenta[Start-1];
        }

        for (Start = Lul-1; Start >= 0; Start--){
            OutFinal[Cuenta[(NumSC[Start].getFinalNum() / XPor) % 10] - 1] = NumSC[Start];
            Cuenta[(NumSC[Start].getFinalNum() / XPor) % 10]--;
        }

        for (Start = 0; Start < Lul; Start++){
            NumSC[Start] = OutFinal[Start];
        }
    }

    /**
     * Método RadixSort: Evalua (Unidades, decenas, centenas y milésimas) y por
     * medio de esto ordena la lista
     * @param Nume: Lista desordenada de números aleatorios
     * @param est: Número más grande posible
     * @return: Lista correctamente ordenada
     */
    public static String RadixSort(Numeros[] Nume, int est){

        int DTemporal = NumMayor(Nume, est);

        for (int k = 1; DTemporal / k > 0; k *= 10){
            SortC(Nume, est, k);
        }

        String Resulta = "Se han ordenado los numeros correctamente, son los siguientes: ";
        return Resulta;
    }

    /**
     * Método BubbleSort: Sort repetitivo que compara dos números y si no están
     * en su lugar los intercambia hasta lograr ordenar toda la lista
     * @param ListaNume: Lista de números aleatorios desordenada
     */
    public static void BubbleSort(Comparable<Numeros>[] ListaNume){
        
        int Lex = ListaNume.length;

        for(int m = 0; m < Lex-1; m++){
            for(int n = 0; n < Lex-m-1; n++){
                if(ListaNume[n].compareTo((Numeros) ListaNume[n+1]) < 0){
                    Comparable<Numeros> Comparador = ListaNume[n];
                    ListaNume[n] = ListaNume[n+1];
                    ListaNume[n+1] = Comparador;
                }
            }
        }
    }
}
